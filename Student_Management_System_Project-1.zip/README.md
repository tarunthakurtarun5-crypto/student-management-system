# Student Management System

A simple responsive Student Management System built with HTML, CSS and JavaScript.

## Features
- Add student records
- Edit student records
- Delete student records
- Search students
- Average marks dashboard
- Attendance summary
- Data stored in browser localStorage
- Responsive design

## Run
Open `index.html` in a browser.

## Live deployment
Upload this folder to a static hosting service such as GitHub Pages, Netlify, or Vercel.
